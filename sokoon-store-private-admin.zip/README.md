# SOKOON Store

Private admin + public storefront starter for SOKOON.

## What changed
- Customers only see the storefront, cart, and checkout.
- Admin is private at `/admin/login`.
- Products start empty so you add your own items.
- Orders are saved with shipping details in `data/orders.json`.
- Bank transfer details are editable in the admin dashboard and shown only at checkout.

## First setup
1. Create a `.env.local` file in the project root.
2. Copy the values from `.env.example` and replace them with your own private values.
3. Run:
   ```bash
   npm install
   npm run dev
   ```

## Admin login
Visit:
- `/admin/login`

Use the email and password you put in `.env.local`.

## Important
Do not put your real email password or bank password inside the code.
Only put your own admin login for this site in `.env.local`.
Real card payments should later be connected through Stripe or another gateway.

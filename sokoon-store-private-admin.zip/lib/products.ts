import fs from 'fs';
import path from 'path';
import { Product } from './types';

const filePath = path.join(process.cwd(), 'data', 'products.json');

export function readProducts(): Product[] {
  const raw = fs.readFileSync(filePath, 'utf-8');
  return JSON.parse(raw) as Product[];
}

export function writeProducts(products: Product[]) {
  fs.writeFileSync(filePath, JSON.stringify(products, null, 2));
}

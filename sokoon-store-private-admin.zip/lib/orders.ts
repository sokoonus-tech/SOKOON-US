import fs from 'fs';
import path from 'path';
import { Order } from './types';

const filePath = path.join(process.cwd(), 'data', 'orders.json');

export function readOrders(): Order[] {
  const raw = fs.readFileSync(filePath, 'utf-8');
  return JSON.parse(raw) as Order[];
}

export function writeOrders(orders: Order[]) {
  fs.writeFileSync(filePath, JSON.stringify(orders, null, 2));
}

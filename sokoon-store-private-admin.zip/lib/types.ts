export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  oldPrice?: number;
  image?: string;
  imageTone?: 'light' | 'dark';
  category: string;
  size: string;
  featured?: boolean;
  stock: number;
  discountLabel?: string;
};

export type CartItem = Product & { quantity: number };

export type OrderStatus = 'new' | 'paid' | 'pending' | 'shipped' | 'completed' | 'cancelled';

export type Order = {
  id: string;
  createdAt: string;
  customer: {
    fullName: string;
    email: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  paymentMethod: 'card' | 'bank_transfer' | 'cash_on_delivery';
  items: Array<{ productId: string; name: string; quantity: number; price: number }>;
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  notes?: string;
  status: OrderStatus;
};

export type PaymentSettings = {
  businessName: string;
  bankName: string;
  accountHolder: string;
  iban: string;
  accountNumber: string;
  swiftCode: string;
  transferInstructions: string;
  enableBankTransfer: boolean;
  enableCashOnDelivery: boolean;
  enableCardOption: boolean;
};

import crypto from 'crypto';
import { cookies } from 'next/headers';
import { NextRequest } from 'next/server';

const COOKIE_NAME = 'sokoon_admin_session';
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;

function getSessionSecret() {
  return process.env.SESSION_SECRET || 'change-this-dev-secret';
}

function sign(value: string) {
  return crypto.createHmac('sha256', getSessionSecret()).update(value).digest('hex');
}

export function createAdminSessionValue() {
  const payload = JSON.stringify({
    email: process.env.ADMIN_EMAIL || '',
    exp: Date.now() + SESSION_TTL_MS
  });
  const encoded = Buffer.from(payload).toString('base64url');
  return `${encoded}.${sign(encoded)}`;
}

function parseSession(token?: string | null) {
  if (!token) return null;
  const [encoded, signature] = token.split('.');
  if (!encoded || !signature) return null;
  if (sign(encoded) !== signature) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as { email: string; exp: number };
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function isAuthenticatedRequest(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  return Boolean(parseSession(token));
}

export function isAuthenticatedServer() {
  const token = cookies().get(COOKIE_NAME)?.value;
  return Boolean(parseSession(token));
}

export function getSessionCookieName() {
  return COOKIE_NAME;
}

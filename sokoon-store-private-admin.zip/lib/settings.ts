import fs from 'fs';
import path from 'path';
import { PaymentSettings } from './types';

const filePath = path.join(process.cwd(), 'data', 'settings.json');

const defaultSettings: PaymentSettings = {
  businessName: 'SOKOON PERFUMES',
  bankName: '',
  accountHolder: '',
  iban: '',
  accountNumber: '',
  swiftCode: '',
  transferInstructions: '',
  enableBankTransfer: true,
  enableCashOnDelivery: true,
  enableCardOption: false
};

export function readSettings(): PaymentSettings {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultSettings, null, 2));
    return defaultSettings;
  }
  const raw = fs.readFileSync(filePath, 'utf-8');
  return { ...defaultSettings, ...(JSON.parse(raw) as Partial<PaymentSettings>) };
}

export function writeSettings(settings: PaymentSettings) {
  fs.writeFileSync(filePath, JSON.stringify(settings, null, 2));
}

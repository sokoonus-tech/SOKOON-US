import Link from 'next/link';
import ProductCard from '@/components/ProductCard';
import { readProducts } from '@/lib/products';

export default function HomePage() {
  const products = readProducts();
  const featured = products.filter((p) => p.featured).slice(0, 4);

  return (
    <main>
      <section className="container hero">
        <div className="hero-box">
          <span className="badge">Luxury Perfume Brand</span>
          <h1>SOKOON</h1>
          <p>
            Build your perfume business with a premium storefront that keeps the customer experience clean and simple.
            Customers only browse, add to cart, and checkout. You manage products, orders, and payment settings privately.
          </p>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginTop: 24 }}>
            <Link href="/products" className="btn btn-primary">Shop Collection</Link>
          </div>

          <div className="grid kpis" style={{ marginTop: 28 }}>
            {[
              ['Private Admin', 'Login separately as the business owner'],
              ['Checkout', 'Address + phone + notes'],
              ['Payments', 'Bank transfer, COD, or card label'],
              ['Orders', 'Saved with full shipping info']
            ].map(([title, text]) => (
              <div className="card kpi" key={title}>
                <strong>{title}</strong>
                <div className="muted" style={{ marginTop: 8 }}>{text}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="hero-art card">
          <div className="fake-box light">
            <div>SOKOON PERFUMES</div>
            <div className="title">S</div>
            <div className="sub">Eau de Parfum</div>
          </div>
          <div className="fake-box dark">
            <div>SOKOON PERFUMES</div>
            <div className="title">S</div>
            <div className="sub">Eau de Parfum</div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end', gap: 16, marginBottom: 24 }}>
            <div>
              <div className="badge">Featured Collection</div>
              <h2 style={{ fontSize: 38, margin: '14px 0 8px' }}>Your store collection</h2>
              <p className="muted">Add your real products from the private admin dashboard. Customers never see the editor.</p>
            </div>
            <Link href="/products" className="btn btn-gold">See All Products</Link>
          </div>

          {featured.length ? (
            <div className="grid product-grid">
              {featured.map((product) => <ProductCard key={product.id} product={product} />)}
            </div>
          ) : (
            <div className="card empty">
              <h3 style={{ marginTop: 0 }}>No featured products yet</h3>
              <p className="muted">Login to the admin page privately and add your products first.</p>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

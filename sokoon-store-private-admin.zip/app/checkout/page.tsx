'use client';

import { useCart } from '@/context/CartContext';
import { PaymentSettings } from '@/lib/types';
import { useEffect, useMemo, useState } from 'react';

const defaultSettings: PaymentSettings = {
  businessName: 'SOKOON PERFUMES',
  bankName: '',
  accountHolder: '',
  iban: '',
  accountNumber: '',
  swiftCode: '',
  transferInstructions: '',
  enableBankTransfer: true,
  enableCashOnDelivery: true,
  enableCardOption: false
};

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart();
  const [status, setStatus] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [settings, setSettings] = useState<PaymentSettings>(defaultSettings);
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    paymentMethod: 'bank_transfer',
    notes: ''
  });

  useEffect(() => {
    fetch('/api/settings').then((res) => res.json()).then((data) => {
      setSettings(data);
      if (!data.enableBankTransfer && data.enableCashOnDelivery) {
        setForm((prev) => ({ ...prev, paymentMethod: 'cash_on_delivery' }));
      }
    }).catch(() => null);
  }, []);

  const discount = useMemo(() => {
    return promoCode.trim().toUpperCase() === 'SOKOON10' ? subtotal * 0.1 : 0;
  }, [promoCode, subtotal]);
  const shipping = items.length ? 8 : 0;
  const total = subtotal + shipping - discount;

  const submitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('');
    if (!items.length) {
      setStatus('Your cart is empty.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: form,
          paymentMethod: form.paymentMethod,
          items: items.map((item) => ({
            productId: item.id,
            name: item.name,
            quantity: item.quantity,
            price: item.price
          })),
          subtotal,
          shipping,
          discount,
          total,
          notes: form.notes
        })
      });

      if (!response.ok) throw new Error('Could not place order');

      clearCart();
      setStatus('Order placed successfully.');
      setForm({
        fullName: '', email: '', phone: '', addressLine1: '', addressLine2: '', city: '', state: '', postalCode: '', country: 'United States', paymentMethod: settings.enableBankTransfer ? 'bank_transfer' : 'cash_on_delivery', notes: ''
      });
      setPromoCode('');
    } catch {
      setStatus('Something went wrong while placing the order.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="section">
      <div className="container grid checkout-grid">
        <form className="card" style={{ padding: 24 }} onSubmit={submitOrder}>
          <h1 style={{ marginTop: 0 }}>Checkout</h1>
          <p className="muted">
            Fill in your address, phone number, and preferred payment method.
          </p>

          <div className="grid form-grid">
            {[
              ['Full name', 'fullName'],
              ['Email', 'email'],
              ['Phone number', 'phone'],
              ['Address line 1', 'addressLine1'],
              ['Address line 2', 'addressLine2'],
              ['City', 'city'],
              ['State / Province', 'state'],
              ['Postal code', 'postalCode'],
              ['Country', 'country']
            ].map(([label, name]) => (
              <label key={name}>
                <span className="label">{label}</span>
                <input
                  className="input"
                  value={(form as Record<string, string>)[name]}
                  required={['fullName', 'email', 'phone', 'addressLine1', 'city', 'state', 'postalCode', 'country'].includes(name)}
                  onChange={(e) => setForm((prev) => ({ ...prev, [name]: e.target.value }))}
                />
              </label>
            ))}
          </div>

          <div style={{ marginTop: 18 }}>
            <label className="label">Payment Method</label>
            <select
              className="select"
              value={form.paymentMethod}
              onChange={(e) => setForm((prev) => ({ ...prev, paymentMethod: e.target.value }))}
            >
              {settings.enableBankTransfer ? <option value="bank_transfer">Manual Bank Transfer</option> : null}
              {settings.enableCashOnDelivery ? <option value="cash_on_delivery">Cash on Delivery</option> : null}
              {settings.enableCardOption ? <option value="card">Card (connect gateway later)</option> : null}
            </select>
          </div>

          <div style={{ marginTop: 18 }}>
            <label className="label">Discount Code</label>
            <input
              className="input"
              placeholder="Try SOKOON10"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
            />
          </div>

          <div style={{ marginTop: 18 }}>
            <label className="label">Order Notes</label>
            <textarea
              className="textarea"
              rows={4}
              placeholder="Special delivery details, building number, or gift note"
              value={form.notes}
              onChange={(e) => setForm((prev) => ({ ...prev, notes: e.target.value }))}
            />
          </div>

          {form.paymentMethod === 'bank_transfer' && settings.enableBankTransfer ? (
            <div className="card" style={{ padding: 18, marginTop: 18 }}>
              <strong>{settings.businessName}</strong>
              <div className="muted" style={{ marginTop: 8, lineHeight: 1.8 }}>
                {settings.bankName ? <>Bank: {settings.bankName}<br /></> : null}
                {settings.accountHolder ? <>Account Holder: {settings.accountHolder}<br /></> : null}
                {settings.iban ? <>IBAN: {settings.iban}<br /></> : null}
                {settings.accountNumber ? <>Account Number: {settings.accountNumber}<br /></> : null}
                {settings.swiftCode ? <>SWIFT: {settings.swiftCode}<br /></> : null}
              </div>
              {settings.transferInstructions ? (
                <p className="muted" style={{ marginBottom: 0 }}>{settings.transferInstructions}</p>
              ) : null}
            </div>
          ) : null}

          {form.paymentMethod === 'cash_on_delivery' ? (
            <div className="card" style={{ padding: 18, marginTop: 18 }}>
              <strong>Cash on Delivery</strong>
              <p className="muted" style={{ marginBottom: 0 }}>Please keep the exact amount ready at delivery if possible.</p>
            </div>
          ) : null}

          <div style={{ marginTop: 18 }}>
            <button className="btn btn-primary" disabled={loading}>
              {loading ? 'Placing order...' : 'Place Order'}
            </button>
          </div>

          {status ? <div className={`notice ${status.includes('wrong') || status.includes('empty') ? 'warning' : ''}`} style={{ marginTop: 16 }}>{status}</div> : null}
        </form>

        <aside className="card sticky-box" style={{ padding: 24 }}>
          <h3>Order Summary</h3>
          <div style={{ display: 'grid', gap: 14 }}>
            {items.map((item) => (
              <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
                <div>
                  <strong>{item.name}</strong>
                  <div className="muted">Qty {item.quantity}</div>
                </div>
                <strong>${(item.quantity * item.price).toFixed(2)}</strong>
              </div>
            ))}
          </div>

          <hr style={{ border: 0, borderTop: '1px solid var(--border)', margin: '18px 0' }} />
          <div style={{ display: 'grid', gap: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Subtotal</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Shipping</span>
              <strong>${shipping.toFixed(2)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Discount</span>
              <strong>-${discount.toFixed(2)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 22 }}>
              <span>Total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}

import ProductCard from '@/components/ProductCard';
import { readProducts } from '@/lib/products';

export default function ProductsPage() {
  const products = readProducts();

  return (
    <main className="section">
      <div className="container">
        <div style={{ marginBottom: 24 }}>
          <div className="badge">SOKOON Collection</div>
          <h1 style={{ fontSize: 46, margin: '14px 0 8px' }}>All Products</h1>
          <p className="muted">Browse your published collection.</p>
        </div>

        {products.length ? (
          <div className="grid product-grid">
            {products.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        ) : (
          <div className="card empty">
            <h3 style={{ marginTop: 0 }}>No products yet</h3>
            <p className="muted">The store owner will add products soon.</p>
          </div>
        )}
      </div>
    </main>
  );
}

'use client';

import { useCart } from '@/context/CartContext';
import { Product } from '@/lib/types';
import { useState } from 'react';

export default function AddToCartButton({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [qty, setQty] = useState(1);
  const [message, setMessage] = useState('');

  return (
    <div>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <input
          className="input"
          type="number"
          min={1}
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          style={{ maxWidth: 120 }}
        />
        <button
          className="btn btn-primary"
          onClick={() => {
            addToCart(product, qty);
            setMessage('Added to cart.');
          }}
        >
          Add to Cart
        </button>
      </div>
      {message ? <div className="notice">{message}</div> : null}
    </div>
  );
}

import { notFound } from 'next/navigation';
import Image from 'next/image';
import ProductVisual from '@/components/ProductVisual';
import { readProducts } from '@/lib/products';
import AddToCartButton from './AddToCartButton';

export default function ProductDetailsPage({ params }: { params: { id: string } }) {
  const products = readProducts();
  const product = products.find((item) => item.id === params.id);
  if (!product) return notFound();

  return (
    <main className="section">
      <div className="container grid product-details-grid">
        <div className="card" style={{ overflow: 'hidden' }}>
          {product.image ? (
            <div className="product-image details-image-wrap">
              <Image src={product.image} alt={product.name} fill className="custom-image" sizes="(max-width: 720px) 100vw, 50vw" />
            </div>
          ) : (
            <ProductVisual tone={product.imageTone} />
          )}
        </div>

        <div className="card" style={{ padding: 28 }}>
          <div className="badge">{product.category}</div>
          <h1 style={{ fontSize: 44, margin: '16px 0 12px' }}>{product.name}</h1>
          <p className="muted" style={{ fontSize: 18, lineHeight: 1.8 }}>{product.description}</p>

          <div className="price-row" style={{ margin: '20px 0' }}>
            <strong style={{ fontSize: 34 }}>${product.price.toFixed(2)}</strong>
            {product.oldPrice ? <span className="old-price">${product.oldPrice.toFixed(2)}</span> : null}
            {product.discountLabel ? <span className="sale">{product.discountLabel}</span> : null}
          </div>

          <div className="grid product-meta-grid" style={{ marginBottom: 22 }}>
            <div className="card" style={{ padding: 16 }}>
              <strong>Size</strong>
              <div className="muted" style={{ marginTop: 8 }}>{product.size}</div>
            </div>
            <div className="card" style={{ padding: 16 }}>
              <strong>Stock</strong>
              <div className="muted" style={{ marginTop: 8 }}>{product.stock} available</div>
            </div>
          </div>

          <AddToCartButton product={product} />
        </div>
      </div>
    </main>
  );
}

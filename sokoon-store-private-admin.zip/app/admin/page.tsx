import { redirect } from 'next/navigation';
import AdminDashboard from '@/components/admin/AdminDashboard';
import { isAuthenticatedServer } from '@/lib/auth';

export default function AdminPage() {
  if (!isAuthenticatedServer()) {
    redirect('/admin/login');
  }

  return <AdminDashboard />;
}

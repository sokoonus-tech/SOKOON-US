'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage(data.error || 'Login failed.');
        return;
      }
      router.push('/admin');
      router.refresh();
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="section">
      <div className="container" style={{ maxWidth: 520 }}>
        <form className="card" style={{ padding: 28 }} onSubmit={submit}>
          <div className="badge">Private business login</div>
          <h1 style={{ marginTop: 16 }}>Admin Login</h1>
          <p className="muted">Only you, or anyone you give your business login to, should use this page.</p>

          <label>
            <span className="label">Business email</span>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>

          <label style={{ marginTop: 16 }}>
            <span className="label">Password</span>
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>

          <button className="btn btn-primary" style={{ marginTop: 18, width: '100%' }} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>

          {message ? <div className="notice warning" style={{ marginTop: 16 }}>{message}</div> : null}
        </form>
      </div>
    </main>
  );
}

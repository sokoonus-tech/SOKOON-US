'use client';

import Link from 'next/link';
import { useCart } from '@/context/CartContext';

export default function CartPage() {
  const { items, updateQuantity, removeFromCart, subtotal } = useCart();
  const shipping = items.length ? 8 : 0;
  const total = subtotal + shipping;

  return (
    <main className="section">
      <div className="container grid checkout-grid">
        <div className="card" style={{ padding: 24 }}>
          <h1 style={{ marginTop: 0 }}>Your Cart</h1>
          {!items.length ? (
            <div className="empty">
              <h3>Your cart is empty.</h3>
              <p className="muted">Add products from the collection to continue.</p>
              <Link href="/products" className="btn btn-primary">Browse Products</Link>
            </div>
          ) : (
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.id}>
                      <td>
                        <strong>{item.name}</strong>
                        <div className="muted">{item.size}</div>
                      </td>
                      <td>${item.price.toFixed(2)}</td>
                      <td>
                        <input
                          className="input"
                          type="number"
                          min={1}
                          value={item.quantity}
                          onChange={(e) => updateQuantity(item.id, Number(e.target.value))}
                          style={{ width: 90 }}
                        />
                      </td>
                      <td>${(item.price * item.quantity).toFixed(2)}</td>
                      <td>
                        <button className="btn btn-outline" onClick={() => removeFromCart(item.id)}>
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <aside className="card sticky-box" style={{ padding: 24 }}>
          <h3>Summary</h3>
          <div style={{ display: 'grid', gap: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Subtotal</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Shipping</span>
              <strong>${shipping.toFixed(2)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 22 }}>
              <span>Total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>
          </div>

          <div style={{ marginTop: 18, display: 'grid', gap: 12 }}>
            <Link href="/checkout" className="btn btn-primary">Proceed to Checkout</Link>
            <Link href="/products" className="btn btn-outline">Continue Shopping</Link>
          </div>
        </aside>
      </div>
    </main>
  );
}

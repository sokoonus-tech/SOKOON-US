import { NextRequest, NextResponse } from 'next/server';
import { readOrders, writeOrders } from '@/lib/orders';
import { isAuthenticatedRequest } from '@/lib/auth';
import { Order, OrderStatus } from '@/lib/types';

export async function POST(request: NextRequest) {
  const payload = await request.json();
  const orders = readOrders();

  const order: Order = {
    id: `ord_${Date.now()}`,
    createdAt: new Date().toISOString(),
    customer: {
      fullName: payload.customer.fullName,
      email: payload.customer.email,
      phone: payload.customer.phone,
      addressLine1: payload.customer.addressLine1,
      addressLine2: payload.customer.addressLine2,
      city: payload.customer.city,
      state: payload.customer.state,
      postalCode: payload.customer.postalCode,
      country: payload.customer.country
    },
    paymentMethod: payload.paymentMethod,
    items: payload.items,
    subtotal: Number(payload.subtotal),
    shipping: Number(payload.shipping),
    discount: Number(payload.discount),
    total: Number(payload.total),
    notes: payload.notes,
    status: payload.paymentMethod === 'cash_on_delivery' ? 'pending' : 'new'
  };

  orders.unshift(order);
  writeOrders(orders);
  return NextResponse.json(order, { status: 201 });
}

export async function GET(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  return NextResponse.json(readOrders());
}

export async function PUT(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = await request.json();
  const orders = readOrders();
  const updated = orders.map((order) =>
    order.id === payload.id
      ? { ...order, status: payload.status as OrderStatus }
      : order
  );
  writeOrders(updated);
  return NextResponse.json({ ok: true });
}

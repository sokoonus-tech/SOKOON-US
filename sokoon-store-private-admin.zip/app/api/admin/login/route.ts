import { NextRequest, NextResponse } from 'next/server';
import { createAdminSessionValue, getSessionCookieName } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const payload = await request.json();
  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPassword = process.env.ADMIN_PASSWORD;

  if (!adminEmail || !adminPassword) {
    return NextResponse.json({ error: 'Admin credentials are not configured yet.' }, { status: 500 });
  }

  if (payload.email !== adminEmail || payload.password !== adminPassword) {
    return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
  }

  const response = NextResponse.json({ ok: true });
  response.cookies.set({
    name: getSessionCookieName(),
    value: createAdminSessionValue(),
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge: 60 * 60 * 24 * 7
  });
  return response;
}

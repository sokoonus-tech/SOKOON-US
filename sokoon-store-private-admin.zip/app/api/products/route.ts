import { NextRequest, NextResponse } from 'next/server';
import { readProducts, writeProducts } from '@/lib/products';
import { Product } from '@/lib/types';
import { isAuthenticatedRequest } from '@/lib/auth';

export async function GET() {
  return NextResponse.json(readProducts());
}

export async function POST(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = await request.json();
  const products = readProducts();

  const product: Product = {
    id: `p${Date.now()}`,
    name: payload.name,
    slug: payload.slug,
    description: payload.description,
    price: Number(payload.price),
    oldPrice: payload.oldPrice ? Number(payload.oldPrice) : undefined,
    image: payload.image || undefined,
    category: payload.category,
    size: payload.size,
    featured: Boolean(payload.featured),
    stock: Number(payload.stock),
    imageTone: payload.imageTone || 'light',
    discountLabel: payload.discountLabel || undefined
  };

  products.unshift(product);
  writeProducts(products);
  return NextResponse.json(product, { status: 201 });
}

export async function PUT(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = await request.json();
  const products = readProducts();
  const updated = products.map((product) =>
    product.id === payload.id
      ? {
          ...product,
          ...payload,
          image: payload.image || undefined,
          price: Number(payload.price),
          oldPrice: payload.oldPrice ? Number(payload.oldPrice) : undefined,
          stock: Number(payload.stock)
        }
      : product
  );
  writeProducts(updated);
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const id = request.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 });
  const products = readProducts().filter((product) => product.id !== id);
  writeProducts(products);
  return NextResponse.json({ ok: true });
}

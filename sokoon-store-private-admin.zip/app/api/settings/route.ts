import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticatedRequest } from '@/lib/auth';
import { readSettings, writeSettings } from '@/lib/settings';
import { PaymentSettings } from '@/lib/types';

export async function GET() {
  return NextResponse.json(readSettings());
}

export async function PUT(request: NextRequest) {
  if (!isAuthenticatedRequest(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const payload = await request.json();
  const current = readSettings();
  const settings: PaymentSettings = {
    ...current,
    businessName: payload.businessName || current.businessName,
    bankName: payload.bankName || '',
    accountHolder: payload.accountHolder || '',
    iban: payload.iban || '',
    accountNumber: payload.accountNumber || '',
    swiftCode: payload.swiftCode || '',
    transferInstructions: payload.transferInstructions || '',
    enableBankTransfer: Boolean(payload.enableBankTransfer),
    enableCashOnDelivery: Boolean(payload.enableCashOnDelivery),
    enableCardOption: Boolean(payload.enableCardOption)
  };

  writeSettings(settings);
  return NextResponse.json(settings);
}

'use client';

import { Order, PaymentSettings, Product } from '@/lib/types';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

const emptyProduct: Omit<Product, 'id'> = {
  name: '',
  slug: '',
  description: '',
  price: 0,
  oldPrice: 0,
  image: '',
  category: '',
  size: '100 ml',
  featured: false,
  stock: 0,
  imageTone: 'light',
  discountLabel: ''
};

const emptySettings: PaymentSettings = {
  businessName: 'SOKOON PERFUMES',
  bankName: '',
  accountHolder: '',
  iban: '',
  accountNumber: '',
  swiftCode: '',
  transferInstructions: '',
  enableBankTransfer: true,
  enableCashOnDelivery: true,
  enableCardOption: false
};

export default function AdminDashboard() {
  const router = useRouter();
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<PaymentSettings>(emptySettings);
  const [form, setForm] = useState(emptyProduct);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [settingsMessage, setSettingsMessage] = useState('');

  const loadProducts = async () => {
    const response = await fetch('/api/products');
    const data = await response.json();
    setProducts(data);
  };

  const loadOrders = async () => {
    const response = await fetch('/api/orders');
    if (response.status === 401) {
      router.push('/admin/login');
      return;
    }
    const data = await response.json();
    setOrders(data);
  };

  const loadSettings = async () => {
    const response = await fetch('/api/settings');
    const data = await response.json();
    setSettings(data);
  };

  useEffect(() => {
    loadProducts();
    loadOrders();
    loadSettings();
  }, []);

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');
    const method = editingId ? 'PUT' : 'POST';
    const response = await fetch('/api/products', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editingId ? { id: editingId, ...form } : form)
    });
    if (!response.ok) {
      setMessage('Could not save product.');
      return;
    }
    setMessage(editingId ? 'Product updated.' : 'Product created.');
    setForm(emptyProduct);
    setEditingId(null);
    loadProducts();
  };

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsMessage('');
    const response = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (!response.ok) {
      setSettingsMessage('Could not save payment settings.');
      return;
    }
    setSettingsMessage('Payment settings updated.');
    loadSettings();
  };

  const deleteProduct = async (id: string) => {
    const response = await fetch(`/api/products?id=${id}`, { method: 'DELETE' });
    if (response.ok) {
      setMessage('Product deleted.');
      loadProducts();
    }
  };

  const updateOrderStatus = async (id: string, status: Order['status']) => {
    const response = await fetch('/api/orders', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status })
    });
    if (response.ok) loadOrders();
  };

  const startEdit = (product: Product) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: product.price,
      oldPrice: product.oldPrice || 0,
      image: product.image || '',
      category: product.category,
      size: product.size,
      featured: Boolean(product.featured),
      stock: product.stock,
      imageTone: product.imageTone || 'light',
      discountLabel: product.discountLabel || ''
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const logout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  };

  return (
    <main className="section">
      <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, gap: 12, flexWrap: 'wrap' }}>
        <div>
          <div className="badge">Private admin area</div>
          <h1 style={{ margin: '10px 0 0' }}>SOKOON Dashboard</h1>
        </div>
        <button className="btn btn-outline" onClick={logout}>Logout</button>
      </div>

      <div className="container grid checkout-grid admin-layout">
        <div className="grid" style={{ gap: 24 }}>
          <form className="card" style={{ padding: 24 }} onSubmit={saveProduct}>
            <h2 style={{ marginTop: 0 }}>Products</h2>
            <p className="muted">Add, edit, and delete your products. Customers will only see what you publish here.</p>

            <div className="grid form-grid">
              {[
                ['Product name', 'name'],
                ['Slug', 'slug'],
                ['Category', 'category'],
                ['Size', 'size'],
                ['Price', 'price'],
                ['Old price', 'oldPrice'],
                ['Stock', 'stock'],
                ['Discount label', 'discountLabel'],
                ['Image URL', 'image']
              ].map(([label, key]) => (
                <label key={key}>
                  <span className="label">{label}</span>
                  <input
                    className="input"
                    value={String((form as any)[key])}
                    onChange={(e) => setForm((prev) => ({
                      ...prev,
                      [key]: ['price', 'oldPrice', 'stock'].includes(key) ? Number(e.target.value) : e.target.value
                    }))}
                    required={['name', 'slug', 'category', 'price', 'stock'].includes(key)}
                  />
                </label>
              ))}
            </div>

            <div style={{ marginTop: 16 }}>
              <label className="label">Description</label>
              <textarea
                className="textarea"
                rows={4}
                value={form.description}
                onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))}
                required
              />
            </div>

            <div className="grid form-grid" style={{ marginTop: 16 }}>
              <label>
                <span className="label">Image Tone</span>
                <select className="select" value={form.imageTone} onChange={(e) => setForm((prev) => ({ ...prev, imageTone: e.target.value as 'light' | 'dark' }))}>
                  <option value="light">Light box style</option>
                  <option value="dark">Dark box style</option>
                </select>
              </label>
              <label>
                <span className="label">Featured</span>
                <select className="select" value={String(form.featured)} onChange={(e) => setForm((prev) => ({ ...prev, featured: e.target.value === 'true' }))}>
                  <option value="false">No</option>
                  <option value="true">Yes</option>
                </select>
              </label>
            </div>

            <div style={{ display: 'flex', gap: 12, marginTop: 18, flexWrap: 'wrap' }}>
              <button className="btn btn-primary">{editingId ? 'Update Product' : 'Create Product'}</button>
              <button type="button" className="btn btn-outline" onClick={() => { setEditingId(null); setForm(emptyProduct); }}>
                Clear Form
              </button>
            </div>

            {message ? <div className="notice" style={{ marginTop: 16 }}>{message}</div> : null}
          </form>

          <form className="card" style={{ padding: 24 }} onSubmit={saveSettings}>
            <h2 style={{ marginTop: 0 }}>Payment & Bank Transfer Settings</h2>
            <p className="muted">These details appear to the customer only during checkout when Bank Transfer is selected.</p>

            <div className="grid form-grid">
              {[
                ['Business name', 'businessName'],
                ['Bank name', 'bankName'],
                ['Account holder', 'accountHolder'],
                ['IBAN', 'iban'],
                ['Account number', 'accountNumber'],
                ['SWIFT code', 'swiftCode']
              ].map(([label, key]) => (
                <label key={key}>
                  <span className="label">{label}</span>
                  <input
                    className="input"
                    value={String((settings as any)[key])}
                    onChange={(e) => setSettings((prev) => ({ ...prev, [key]: e.target.value }))}
                  />
                </label>
              ))}
            </div>

            <div style={{ marginTop: 16 }}>
              <label className="label">Transfer instructions</label>
              <textarea
                className="textarea"
                rows={4}
                value={settings.transferInstructions}
                onChange={(e) => setSettings((prev) => ({ ...prev, transferInstructions: e.target.value }))}
                placeholder="Example: Send the transfer, then email your receipt with the order number."
              />
            </div>

            <div className="grid form-grid" style={{ marginTop: 16 }}>
              {[
                ['Enable bank transfer', 'enableBankTransfer'],
                ['Enable cash on delivery', 'enableCashOnDelivery'],
                ['Show card option label', 'enableCardOption']
              ].map(([label, key]) => (
                <label key={key}>
                  <span className="label">{label}</span>
                  <select className="select" value={String((settings as any)[key])} onChange={(e) => setSettings((prev) => ({ ...prev, [key]: e.target.value === 'true' }))}>
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                  </select>
                </label>
              ))}
            </div>

            <button className="btn btn-primary" style={{ marginTop: 18 }}>Save Payment Settings</button>
            {settingsMessage ? <div className="notice" style={{ marginTop: 16 }}>{settingsMessage}</div> : null}
          </form>
        </div>

        <aside className="grid" style={{ gap: 24 }}>
          <div className="card sticky-box" style={{ padding: 24 }}>
            <h3>Current Products</h3>
            {products.length === 0 ? <p className="muted">No products yet. Add your first product from the form.</p> : null}
            <div style={{ display: 'grid', gap: 14 }}>
              {products.map((product) => (
                <div key={product.id} className="card" style={{ padding: 16 }}>
                  <strong>{product.name}</strong>
                  <div className="muted" style={{ marginTop: 6 }}>
                    ${product.price.toFixed(2)} · {product.stock} in stock
                  </div>
                  <div style={{ display: 'flex', gap: 10, marginTop: 12, flexWrap: 'wrap' }}>
                    <button className="btn btn-outline" onClick={() => startEdit(product)}>Edit</button>
                    <button className="btn btn-primary" onClick={() => deleteProduct(product.id)}>Delete</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card" style={{ padding: 24 }}>
            <h3>Customer Orders</h3>
            {orders.length === 0 ? <p className="muted">No orders yet.</p> : null}
            <div style={{ display: 'grid', gap: 16 }}>
              {orders.map((order) => (
                <div key={order.id} className="card" style={{ padding: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                    <strong>{order.customer.fullName}</strong>
                    <span className="badge">{order.status}</span>
                  </div>
                  <div className="muted" style={{ marginTop: 8, lineHeight: 1.7 }}>
                    {order.customer.email}<br />
                    {order.customer.phone}<br />
                    {order.customer.addressLine1}{order.customer.addressLine2 ? `, ${order.customer.addressLine2}` : ''}<br />
                    {order.customer.city}, {order.customer.state}, {order.customer.postalCode}, {order.customer.country}
                  </div>
                  <div style={{ marginTop: 10 }}>
                    <strong>Total:</strong> ${order.total.toFixed(2)} · <span className="muted">{order.paymentMethod}</span>
                  </div>
                  <div className="muted" style={{ marginTop: 10 }}>
                    {order.items.map((item) => `${item.name} × ${item.quantity}`).join(' • ')}
                  </div>
                  {order.notes ? <div className="muted" style={{ marginTop: 10 }}>Note: {order.notes}</div> : null}
                  <div style={{ marginTop: 12 }}>
                    <label className="label">Update status</label>
                    <select className="select" value={order.status} onChange={(e) => updateOrderStatus(order.id, e.target.value as Order['status'])}>
                      <option value="new">New</option>
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="shipped">Shipped</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}

export default function ProductVisual({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  return (
    <div className={`product-image ${tone === 'dark' ? 'alt-dark' : ''}`}>
      <div className={`product-box ${tone === 'dark' ? 'dark' : 'light'}`}>
        <div style={{ fontSize: 16, letterSpacing: 2 }}>SOKOON</div>
        <div className="big">S</div>
        <div className="sub">Eau de Parfum</div>
      </div>
    </div>
  );
}

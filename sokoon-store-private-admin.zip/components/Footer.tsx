export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="card" style={{ padding: 24 }}>
          <strong>SOKOON</strong>
          <p className="muted" style={{ marginTop: 10 }}>
            Luxury perfume store starter built for easy product editing, discounts, checkout,
            and customer address collection.
          </p>
        </div>
      </div>
    </footer>
  );
}

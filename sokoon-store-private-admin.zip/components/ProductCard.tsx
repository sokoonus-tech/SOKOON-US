import Link from 'next/link';
import Image from 'next/image';
import { Product } from '@/lib/types';
import ProductVisual from './ProductVisual';

export default function ProductCard({ product }: { product: Product }) {
  return (
    <article className="card product-card">
      <Link href={`/product/${product.id}`}>
        {product.image ? (
          <div className="product-image custom-image-wrap">
            <Image src={product.image} alt={product.name} fill className="custom-image" sizes="(max-width: 720px) 100vw, 25vw" />
          </div>
        ) : (
          <ProductVisual tone={product.imageTone} />
        )}
      </Link>
      <div className="product-content">
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
          <div>
            <div className="badge">{product.category}</div>
            <h3 style={{ margin: '12px 0 8px' }}>{product.name}</h3>
          </div>
          <div className="muted">{product.size}</div>
        </div>

        <p className="muted" style={{ minHeight: 48 }}>{product.description}</p>

        <div className="price-row" style={{ margin: '14px 0 18px' }}>
          <strong style={{ fontSize: 24 }}>${product.price.toFixed(2)}</strong>
          {product.oldPrice ? <span className="old-price">${product.oldPrice.toFixed(2)}</span> : null}
          {product.discountLabel ? <span className="sale">{product.discountLabel}</span> : null}
        </div>

        <div style={{ display: 'flex', gap: 12 }}>
          <Link href={`/product/${product.id}`} className="btn btn-primary" style={{ flex: 1 }}>
            View Product
          </Link>
        </div>
      </div>
    </article>
  );
}

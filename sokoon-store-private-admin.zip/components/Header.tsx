'use client';

import Link from 'next/link';
import { useCart } from '@/context/CartContext';

export default function Header() {
  const { totalItems } = useCart();

  return (
    <header className="header">
      <div className="container nav">
        <Link href="/" className="brand">
          <small>SUKOON PERFUMES</small>
          SOKOON
        </Link>

        <nav className="nav-links">
          <Link href="/products">Products</Link>
          <Link href="/checkout">Checkout</Link>
          <Link href="/cart" className="btn btn-primary">
            Cart ({totalItems})
          </Link>
        </nav>
      </div>
    </header>
  );
}
